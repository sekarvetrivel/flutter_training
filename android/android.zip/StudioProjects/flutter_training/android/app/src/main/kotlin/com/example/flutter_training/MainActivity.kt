package com.example.flutter_training

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
